#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class GameOverPage;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void mousePressEvent(QMouseEvent *event) override;

private:
    int score = 0;
    bool gameRunning = true;

    GameOverPage *gameOverPage;
};

#endif // MAINWINDOW_H
