#include "mainwindow.h"
#include "GameOverPage.h"

#include <QMouseEvent>
#include <QApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    gameOverPage = new GameOverPage(this);

    // BACK button → return to game
    connect(gameOverPage, &GameOverPage::backToMenu,
            this, [this]()
            {
                score = 0;
                gameRunning = true;
                this->show();
            });

    // RESTART button → reset game
    connect(gameOverPage, &GameOverPage::restartGame,
            this, [this]()
            {
                score = 0;
                gameRunning = true;
                this->show();
            });
}

MainWindow::~MainWindow() {}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (!gameRunning)
        return;

    if (event->button() == Qt::LeftButton)
    {
        score += 10;
    }
    else if (event->button() == Qt::RightButton)
    {
        gameRunning = false;

        gameOverPage->setScore(score);

        if (score >= 50)
            gameOverPage->setResult(true);
        else
            gameOverPage->setResult(false);

        this->hide();
        gameOverPage->exec();
    }
}
